package aki_izumi.com.continuoustimer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.EditText
import android.widget.Toast
import androidx.core.content.edit
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    val maxTimerNum = 3

    lateinit var minET :Array<EditText>
    lateinit var secET :Array<EditText>
    lateinit var repNumET :Array<EditText>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val powerManager = applicationContext!!.getSystemService(Context.POWER_SERVICE) as PowerManager
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            }
        }

        minET = arrayOf(minute1,minute2,minute3)
        secET = arrayOf(second1,second2,second3)
        repNumET = arrayOf(repNum1,repNum2,repNum3)


        setEditTexts()

        for(i in 0 until maxTimerNum) {
            minET[i].addTextChangedListener(TimerTextWatcher(minET[i], 2,minET[i],secET[i],repNumET[i]))
            secET[i].addTextChangedListener(SecTextWatcher(secET[i], 2,minET[i],repNumET[i]))
            repNumET[i].addTextChangedListener(TimerTextWatcher(repNumET[i], 3,minET[i],secET[i],repNumET[i]))
        }

        repNumSet.addTextChangedListener(CustomTextWatcher(repNumSet,3))



        startButton.setOnClickListener {
            var canStart = canStart()

            if(!canStart){
                Toast.makeText(this,"At least one timer must work!!",Toast.LENGTH_LONG).show()
                Log.i("tag","startButton")
                return@setOnClickListener
            }

            Log.i("tag","startButton")
            val pref = getSharedPreferences("TimerData",Context.MODE_PRIVATE)
            pref.edit {

                for(i in 0..2) {
                    putInt("T${i+1}", convertToSec(minET[i].text.toString(), secET[i].text.toString()))
                    putInt("REP_NUM${i+1}", Integer.parseInt(repNumET[i].text.toString()))
                }

                putInt("REP_NUM_SET",Integer.parseInt(repNumSet.text.toString()))

                putBoolean("IS_STARTED",false)
                putInt("TIMER_NUM",0)
                putInt("TIMER_CNT",0)
                putInt("SET_CNT",0)

            }


            val intent = Intent(this,TimerActivity::class.java)

            startActivity(intent)
        }

    }


    private fun convertToSec(min:String,sec:String):Int{
        return Integer.parseInt(min)*60 +Integer.parseInt(sec)
    }


    private fun setEditTexts(){

        val pref = getSharedPreferences("TimerData",Context.MODE_PRIVATE)


        for(i in 0..2) {
            val t = pref.getInt("T${i+1}",0)
            val repNum = pref.getInt("REP_NUM${i+1}",0)

            minET[i].setText("%02d".format(t/60))

            secET[i].setText("%02d".format(t%60))

            repNumET[i].setText("%03d".format(repNum))
        }

        val set = pref.getInt("REP_NUM_SET",1)

        repNumSet.setText("%03d".format(set))

    }

    private fun canStart():Boolean{
        for(i in 0 until maxTimerNum){
            if(repNumET[i].text.toString() != "000"){
                return true
            }
        }
        return false
    }
}



class SecTextWatcher(secEditText: EditText, maxLen:Int,minEditText: EditText,repNumEditText: EditText):TimerTextWatcher(secEditText,maxLen,minEditText, secEditText, repNumEditText){
    override fun afterTextChanged(s: Editable?) {
        super.afterTextChanged(s)
        val v = Integer.parseInt(super.editText.text.toString())

        //over 59sec
        if(v > 60){
            super.editText.setText("59")
            //move cursor to last
            super.editText.setSelection(super.maxLen)
        }

    }
}


open class TimerTextWatcher(editText: EditText, maxLen:Int,minEditText: EditText ,secEditText: EditText,repNumEditText: EditText):CustomTextWatcher(editText,maxLen){
    val minEditText = minEditText
    val secEditText = secEditText
    val repNumEditText = repNumEditText

    override fun afterTextChanged(s: Editable?) {
        super.afterTextChanged(s)
        val minText:String = minEditText.text.toString()
        val secText:String = secEditText.text.toString()
        val repNumText :String = repNumEditText.toString()


        //is time 0? and repNum > 0?
        if(minText == "00" && secText == "00"){
            if(editText != repNumEditText || s.toString() != "000" ) {
                repNumEditText.setText("000")
            }

        }

        //move cursor to last
        editText.setSelection(maxLen)

    }
}



open class CustomTextWatcher(editText: EditText, maxLen:Int):TextWatcher{
    val editText = editText
    val maxLen = maxLen


    override fun afterTextChanged(s: Editable?) {

        var str:String = s.toString()
        if(str.length ==0){
            str = "0"
        }

        //input type is number
        //str can convert to Int
        var v = Integer.parseInt(str);
        if(v <0){
            v = 0
        }

        //is over maxLen?
        str = v.toString()
        if(str.length >maxLen){
            v = 0
        }

        str ="%0${maxLen}d".format(v)
        if(str != s.toString()) {
            editText.setText(str)
        }
        //move cursor to last
        editText.setSelection(maxLen)

    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
        return
    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        return
    }
}