package aki_izumi.com.continuoustimer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.content.edit
import kotlinx.android.synthetic.main.activity_timer.*

class TimerActivity : AppCompatActivity() {




    val handler =Handler()
    val runnable =object : Runnable {
        override fun run() {
            val isEnd = updateTimer()


            if(!isEnd){
                handler.postDelayed(this, 100);
                return
            }
            Toast.makeText(this@TimerActivity,"ContinuousTimer has finished",Toast.LENGTH_LONG).show()
            finish()
        }

    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_timer)




        val pref = getSharedPreferences("TimerData",Context.MODE_PRIVATE)
        val isStarted = pref.getBoolean("IS_STARTED",false)

        if(!isStarted) {
            val serviceIntent = Intent(this, TimerService::class.java)

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {

                startService(serviceIntent)
            } else {

                startForegroundService(serviceIntent)
            }
        }
        pref.edit {
            putBoolean("IS_STARTED",true)
        }





        handler.post(runnable)

        cancelButton.setOnClickListener{
            Toast.makeText(this,"ContinuousTimer is canceled", Toast.LENGTH_LONG).show()

            val serviceIntent = Intent(this, TimerService::class.java)
            stopService(serviceIntent)
            finish()
        }


    }



    override fun onDestroy() {
        super.onDestroy()

        handler.removeCallbacks(runnable);
    }

    //return value:has the timer ended
    fun updateTimer():Boolean{
        val pref = getSharedPreferences("TimerData",Context.MODE_PRIVATE)

        val min = pref.getInt("MINUTE",0)
        val sec = pref.getInt("SECOND",0)
        timerText.text = "%02d:%02d".format(min,sec)

        val timerNum = pref.getInt("TIMER_NUM",0)
        timerTypeText.text = "Timer${timerNum+1}"

        timer.background = when(timerNum){
            0->getDrawable(R.color.timer1)
            1->getDrawable(R.color.timer2)
            else->getDrawable(R.color.timer3)
        }

        val maxTimerCnt = pref.getInt("REP_NUM${timerNum+1}",0)
        val timerCnt = pref.getInt("TIMER_CNT",0)
        repText.text = "%,3d/%-,3d".format(timerCnt+1,maxTimerCnt)


        val maxSetCnt = pref.getInt("REP_NUM_SET",0)
        val setCnt = pref.getInt("SET_CNT",0)
        setText.text = "%,3d/%-,3d".format(setCnt+1,maxSetCnt)

        return setCnt>= maxSetCnt
    }
}
