package aki_izumi.com.continuoustimer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.PendingIntent.FLAG_CANCEL_CURRENT
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.edit

class TimerService :Service() {

    lateinit var soundPool: SoundPool
    lateinit var soundResIds: Array<Int>

    lateinit var notificationBuilder :NotificationCompat.Builder
    lateinit var notificationManager: NotificationManager

    val notificationId = 1
    val countDownInterval:Long = 100

    lateinit var countDownTimer: CountDownTimer
    //how many times timers have to repeat
    //0->timer1,1->timer2, 2->timer3 and 3-> set
    lateinit var repNum:Array<Int>


    //milliSecond of timer
    //1000*(60*min+sec)
    lateinit var timerMS:Array<Long>


    //which timer is working now
    //0origin
    //0->timer1,1->timer2 and 2->timer3
    var timerNum:Int =0

    //how many times timer has repeated
    var timerCnt:Int = 0

    //how many times timer has repeated
    var setCnt:Int = 0



    inner class ContinuousCountDownTimer(millisInFuture: Long,
                                         countDownInterval: Long
    ):CountDownTimer(millisInFuture, countDownInterval){

        override fun onTick(millisUntilFinished: Long) {



            var sUntilFinished = millisUntilFinished/1000
            if(millisUntilFinished%1000 >0){
                sUntilFinished++
            }

            val min :Int = (sUntilFinished/60).toInt()
            val sec :Int = (sUntilFinished%60).toInt()
            updateNotification(min,sec)
            saveState(min,sec)


        }

        override fun onFinish() {


            timerCnt++;

            updateCnt()
            Log.i("tag","$timerCnt ,${timerMS[timerNum]},${repNum[timerNum]}")
            saveState(0,0)



            playSound()


            //has timer finished?
            if(setCnt == repNum[3]){
                finishTimer()
                return
            }

            startNextTimerService()
        }

    }



    override fun onCreate() {
        super.onCreate()

    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()


        setAudioSource()



        //set timerMS and repNum value with sharedPreference
        setParams()

        updateCnt()



        countDownTimer = ContinuousCountDownTimer(timerMS[timerNum],countDownInterval)
        countDownTimer.start()

        return START_NOT_STICKY
    }

    fun createNotification(){
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        //create notification channel
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "ContinuousTimerNotificationChannelId",
                "ContiuousTimerNotification",
                NotificationManager.IMPORTANCE_LOW
            )
            notificationManager.createNotificationChannel(channel)
        }


        notificationBuilder = when(Build.VERSION.SDK_INT < Build.VERSION_CODES.O){
            true-> NotificationCompat.Builder(this)
            else-> NotificationCompat.Builder(this, "ContinuousTimerNotificationChannelId")
        }

        //set pendingIntent for touching notification
        val notificationIntent = Intent(this,   TimerActivity::class.java)
            .addFlags(FLAG_ACTIVITY_SINGLE_TOP)

        val pendingIntent = PendingIntent.getActivity(
            this,
            0, notificationIntent, FLAG_CANCEL_CURRENT
        )
        notificationBuilder= notificationBuilder
            .setSmallIcon(R.drawable.ic_alarm_72dp)
            .setContentIntent(pendingIntent)
            .setVibrate(null)
            .setSound(null)



        //create notification
        val notification = notificationBuilder.build()

        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            notificationManager.notify(notificationId, notification)
        }else{
            startForeground(notificationId, notification)
        }
    }

    fun setAudioSource(){
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .build()

        if(!::soundPool.isInitialized) {
            soundPool = SoundPool.Builder()
                .setMaxStreams(1)
                .setAudioAttributes(audioAttributes)
                .build()

            soundResIds = arrayOf(
                soundPool.load(this, R.raw.whistle, 1),
                soundPool.load(this, R.raw.whistle_long, 1),
                soundPool.load(this, R.raw.whistle_double, 1)
            )
        }
    }

    fun setParams(){
        val pref = getSharedPreferences("TimerData",Context.MODE_PRIVATE)

        timerMS = Array<Long>(3,{0})
        for(i in 0..2){
            timerMS[i] = pref.getInt("T${i+1}",0).toLong() * 1000
        }

        repNum  = Array<Int>(4,{0})
        for(i in 0..2){
            repNum[i] = pref.getInt("REP_NUM${i+1}",0)
        }
        repNum[3] = pref.getInt("REP_NUM_SET",0)
        timerNum = pref.getInt("TIMER_NUM",0)
        timerCnt =pref.getInt("TIMER_CNT",0)
        setCnt = pref.getInt("SET_CNT",0)

    }
    fun updateNotification(min:Int,sec:Int) {

        var str = "Timer${timerNum+1}  %02d:%02d  ".format(min,sec)
        str += "%,3d/%-,3d  ".format(timerCnt+1,repNum[timerNum])
        str += "%,3d/%-,3d  ".format(setCnt+1,repNum[3])
        val notification = notificationBuilder
            .setContentText(str)
            .setVibrate(null)
            .setSound(null)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        notificationManager.notify(notificationId, notification)


    }



    fun startNextTimerService(){

        val serviceIntent = Intent(this,TimerService::class.java)
        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.O){

            startService(serviceIntent)
        }else {

            startForegroundService(serviceIntent)
        }

    }


    fun updateCnt() {
        while(timerCnt >= repNum[timerNum]){
            timerCnt = 0
            timerNum++
            if(timerNum >=3){
                timerNum = 0
                setCnt++;
            }

            if(setCnt >=repNum[3]){
                break

            }

        }
    }

    fun saveState(min:Int,sec:Int){
        val pref = getSharedPreferences("TimerData",Context.MODE_PRIVATE)


        pref.edit {

            putInt("MINUTE",min)
            putInt("SECOND",sec)


            putInt("TIMER_NUM",timerNum)
            putInt("TIMER_CNT",timerCnt)
            putInt("SET_CNT",setCnt)
        }
    }

    fun playSound(){
        var soundCnt = 0

        //has timer changed?
        if(timerCnt ==0){
            soundCnt++
        }

        //has timer finished?
        if(setCnt == repNum[3]){
            soundCnt++
        }


        soundPool.play(soundResIds[soundCnt],1.0f,1.0f,0,0,1.0f)
    }

    fun finishTimer(){
        stopSelf()
        notificationManager.cancel(notificationId)

    }

    override fun onDestroy() {
        super.onDestroy()
        countDownTimer.cancel()
    }
    //not use onBind
    override fun onBind(intent: Intent?): IBinder? {
        return null;
    }



}

